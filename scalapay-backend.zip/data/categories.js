export default ['T-Shirt', 'Pants']
