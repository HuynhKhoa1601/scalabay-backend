export default {
    clientId: "30eabf1c174d3a5168cc",
    clientSecret: "d863ad4b531385fa6f680dbf0fd7d14b7c0b7fa7"
}