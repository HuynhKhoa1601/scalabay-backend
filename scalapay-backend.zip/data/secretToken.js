export default {
    accessTokenSecret: "test oauth2.0 comparensaveBGL",
    refreshTokenSecret: "test oauth2.0 comparensaveBGL refresh"
}